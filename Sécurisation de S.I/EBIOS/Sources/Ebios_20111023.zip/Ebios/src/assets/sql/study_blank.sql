/* ---------------------------------------------------------------------------------------------------------------------*/
/* Base de connaissance */ 
/* ---------------------------------------------------------------------------------------------------------------------*/

/* INFORMATION */
DROP TABLE IF EXISTS INFORMATION ;
CREATE TABLE INFORMATION (
  URL TEXT,
  dateCreation DATE,  
  dateModification DATE
);

/* MODULE */
DROP TABLE IF EXISTS MODULE ;
CREATE TABLE MODULE (
  idMODULE INTEGER PRIMARY KEY AUTOINCREMENT, 
	numero TEXT,
	libelle TEXT,
  dateCreation DATE,  
  dateModification DATE
);

/* ACTIVITE */
DROP TABLE IF EXISTS ACTIVITE ;
CREATE TABLE ACTIVITE (
	idACTIVITE INTEGER PRIMARY KEY AUTOINCREMENT,
	numero TEXT,
	libelle TEXT,
  idMODULE INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idMODULE) REFERENCES MODULE(idMODULE)  
);

/* ACTION */
DROP TABLE IF EXISTS ACTION ;
CREATE TABLE ACTION (
	idACTION INTEGER PRIMARY KEY AUTOINCREMENT,
	numero TEXT,
	libelle TEXT,
  retenu BOOLEAN,  
  vue TEXT,
  idLIVRABLE INT,
	charges TEXT,
  duree TEXT,
  consignes TEXT,  
  idACTIVITE INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idLIVRABLE) REFERENCES LIVRABLE(idLIVRABLE),
  FOREIGN KEY(idACTIVITE) REFERENCES ACTIVITE(idACTIVITE)  
);

/* ROLE */
DROP TABLE IF EXISTS ROLE ;
CREATE TABLE ROLE (
	idROLE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  dateCreation DATE,  
  dateModification DATE  
);

/* REFERENTIEL */
DROP TABLE IF EXISTS REFERENTIEL ;
CREATE TABLE REFERENTIEL (
	idREFERENTIEL INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  reference TEXT,
  dateCreation DATE,  
  dateModification DATE  
);

/* LIGNE */
DROP TABLE IF EXISTS LIGNE ;
CREATE TABLE LIGNE (
	idLIGNE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  dateCreation DATE,  
  dateModification DATE  
);

/* LIVRABLE */
DROP TABLE IF EXISTS LIVRABLE ;
CREATE TABLE LIVRABLE (
	idLIVRABLE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  trame TEXT,
  produire BOOLEAN,
  dateCreation DATE,  
  dateModification DATE  
);

/* CRITERE */
DROP TABLE IF EXISTS CRITERE ;
CREATE TABLE CRITERE (
	idCRITERE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  definition TEXT,
  dateCreation DATE,  
  dateModification DATE  
);

/* NCRITERE */
DROP TABLE IF EXISTS NCRITERE ;
CREATE TABLE NCRITERE (
	idNCRITERE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  ordre INT,  
  idCRITERE INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE) ON DELETE CASCADE
);

/* TBS */
DROP TABLE IF EXISTS TBS ;
CREATE TABLE TBS (
	idTBS INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  titre TEXT,
  description TEXT,  
  ordre INT,  
  idTBSparent INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idTBSparent) REFERENCES TBS(idTBS)  
);

/* TOBJECTIFS */
DROP TABLE IF EXISTS TOBJECTIFS ;
CREATE TABLE TOBJECTIFS (
	idTOBJECTIFS INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  definition TEXT,  
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE  
);

/* TMENACES */
DROP TABLE IF EXISTS TMENACES ;
CREATE TABLE TMENACES (
	idTMENACES INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  exemples TEXT,  
  ordre INT,  
  idTBS INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idTBS) REFERENCES TBS(idTBS)  
);

/* PREREQUIS */
DROP TABLE IF EXISTS PREREQUIS ;
CREATE TABLE PREREQUIS (
	idPREREQUIS INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  idTMENACES INT,  
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idTMENACES) REFERENCES TMENACES(idTMENACES)  
);

/* TMESURES */
DROP TABLE IF EXISTS TMESURES ;
CREATE TABLE TMESURES (
	idTMESURES INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  exemples TEXT,  
  ordre INT,  
  idREFERENTIEL INT,
  idTMESURESparent,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idREFERENTIEL) REFERENCES REFERENTIEL(idREFERENTIEL)  
);

/* TIMPACTS */
DROP TABLE IF EXISTS TIMPACTS ;
CREATE TABLE TIMPACTS (
	idTIMPACTS INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  exemples TEXT,  
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE  
);

/* TVULN */
DROP TABLE IF EXISTS TVULN ;
CREATE TABLE TVULN (
	idTVULN INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE  
);

/* TSOURCES */
DROP TABLE IF EXISTS TSOURCES ;
CREATE TABLE TSOURCES (
	idTSOURCES INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  exemples TEXT,
  ordre INT, 
  retenu BOOLEAN,
  justification TEXT,
  dateCreation DATE,  
  dateModification DATE 
);

/* TPARAMETRES */
DROP TABLE IF EXISTS TPARAMETRES ;
CREATE TABLE TPARAMETRES (
	idTPARAMETRES INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  exemples TEXT,
  ordre INT,
  retenu BOOLEAN,
  justification TEXT,
  dateCreation DATE,  
  dateModification DATE  
);

/* AFFECTER */
DROP TABLE IF EXISTS AFFECTER ;
CREATE TABLE AFFECTER (
	idCRITERE INT,
	idTMENACES INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE),  
  FOREIGN KEY(idTMENACES) REFERENCES TMENACES(idTMENACES),
  PRIMARY KEY(idCRITERE, idTMENACES)  
);

/* SERVIR */
DROP TABLE IF EXISTS SERVIR ;
CREATE TABLE SERVIR (
	idLIGNE INT,
	idTMESURES INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idLIGNE) REFERENCES LIGNE(idLIGNE),  
  FOREIGN KEY(idTMESURES) REFERENCES TMESURES(idTMESURES),
  PRIMARY KEY(idLIGNE, idTMESURES)  
);

/* PROFITER */
DROP TABLE IF EXISTS PROFITER ;
CREATE TABLE PROFITER (
	idTMENACES INT,
	idTVULN INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idTMENACES) REFERENCES TMENACES(idTMENACES),  
  FOREIGN KEY(idTVULN) REFERENCES TVULN(idTVULN),
  PRIMARY KEY(idTMENACES, idTVULN)  
);

/* STATUT */
DROP TABLE IF EXISTS STATUT ;
CREATE TABLE STATUT (
	idSTATUT INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	dateCreation DATE,  
  	dateModification DATE
);

/* NRISQUE */
DROP TABLE IF EXISTS NRISQUE ;
CREATE TABLE NRISQUE (
	idNRISQUE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  codeCouleur TEXT,  
  dateCreation DATE,  
  dateModification DATE
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Module 1 */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* ETUDE */
DROP TABLE IF EXISTS ETUDE ;
CREATE TABLE ETUDE(
	idETUDE INTEGER PRIMARY KEY AUTOINCREMENT,
	but TEXT,
	butBrut TEXT,
  diversContexte TEXT,  
  diversContexteBrut TEXT,
  diversPerimetre TEXT, 
  diversPerimetreBrut TEXT,
  dateCreation DATE,  
  dateModification DATE
);

/* PERSONNE */
DROP TABLE IF EXISTS PERSONNE ;
CREATE TABLE PERSONNE(
	idPERSONNE INTEGER PRIMARY KEY AUTOINCREMENT,
	nom TEXT,
  prenom TEXT,
  fonction TEXT,  
  adresseElectronique TEXT,  
  telephone TEXT,  
  adresseGeographique TEXT,  
  participe BOOLEAN,
  dateCreation DATE,  
  dateModification DATE
);

/* IMAGE */
DROP TABLE IF EXISTS IMAGE ;
CREATE TABLE IMAGE(
	idIMAGE INTEGER PRIMARY KEY AUTOINCREMENT,
	nom TEXT,
  URL TEXT,
  dateCreation DATE,  
  dateModification DATE
);

/* BS */
DROP TABLE IF EXISTS BS;
CREATE TABLE BS(
	idBS INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  retenu BOOLEAN,  
  proprietaire INT,
  idTBS INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(proprietaire) REFERENCES PERSONNE(idPERSONNE),  
  FOREIGN KEY(idTBS) REFERENCES TBS(idTBS)
);


/* BS_POSITIONS */
DROP TABLE IF EXISTS BS_POSITIONS;
CREATE TABLE BS_POSITIONS(
	idBSPOSITIONS INTEGER PRIMARY KEY AUTOINCREMENT,
	xml TEXT,
  dateCreation DATE,  
  dateModification DATE
);

/* BE */
DROP TABLE IF EXISTS BE;
CREATE TABLE BE(
	idBE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  retenu BOOLEAN,  
  depositaire INT,
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(depositaire) REFERENCES PERSONNE(idPERSONNE)
);

/* BE_POSITIONS */
DROP TABLE IF EXISTS BE_POSITIONS;
CREATE TABLE BE_POSITIONS(
	idBEPOSITIONS INTEGER PRIMARY KEY AUTOINCREMENT,
	xml TEXT,
  dateCreation DATE,  
  dateModification DATE
);


/* REGLE */
DROP TABLE IF EXISTS REGLE ;
CREATE TABLE REGLE(
	idREGLE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  idACTION INT,
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idACTION) REFERENCES ACTION(idACTION)  
);

/* CROISER : lien entre les BE et les BS */
DROP TABLE IF EXISTS CROISER;
CREATE TABLE CROISER(
	idBE INT,
	idBS INT,  
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idBE) REFERENCES BE(idBE),  
  FOREIGN KEY(idBS) REFERENCES BS(idBS),
  PRIMARY KEY(idBE, idBS)  
);

/* LIERBS : hierarchie entre les BS */
DROP TABLE IF EXISTS LIERBS;
CREATE TABLE LIERBS(
	idBSparent INT,
	idBSenfant INT,
  relation TEXT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idBSparent) REFERENCES BS(idBS),  
  FOREIGN KEY(idBSenfant) REFERENCES BS(idBS),
  PRIMARY KEY(idBSparent, idBSenfant)  
);

/* NGRISQUE */
DROP TABLE IF EXISTS NGRISQUE ;
CREATE TABLE NGRISQUE(
	idNGRISQUE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE
);

/* NVRISQUE */
DROP TABLE IF EXISTS NVRISQUE ;
CREATE TABLE NVRISQUE(
	idNVRISQUE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE
);

/* PARAMETRE */
DROP TABLE IF EXISTS PARAMETRE ;
CREATE TABLE PARAMETRE(
	idPARAMETRE INTEGER PRIMARY KEY AUTOINCREMENT,
	idTPARAMETRES INT,
	libelle TEXT,
  idSTATUT INT,
  justification TEXT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idTPARAMETRES) REFERENCES TPARAMETRES(idTPARAMETRES),
  FOREIGN KEY(idSTATUT) REFERENCES STATUT(idSTATUT)
);

/* SOURCE */
DROP TABLE IF EXISTS SOURCE ;
CREATE TABLE SOURCE(
	idSOURCE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  description TEXT,  
  retenu BOOLEAN,
  idTSOURCES INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idTSOURCES) REFERENCES TSOURCES(idTSOURCES)  
);

/* PARTICIPER */
DROP TABLE IF EXISTS PARTICIPER ;
CREATE TABLE PARTICIPER(
	idACTION INT,
  idPERSONNE INT,  
  idROLE INT,
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idACTION) REFERENCES ACTION(idACTION),
  FOREIGN KEY(idPERSONNE) REFERENCES PERSONNE(idPERSONNE),
  FOREIGN KEY(idROLE) REFERENCES ROLE(idROLE), 
  PRIMARY KEY(idACTION, idPERSONNE, idROLE)
);

/* REQUERIR */
DROP TABLE IF EXISTS REQUERIR ;
CREATE TABLE REQUERIR(
	idACTION INT,
  idLIVRABLE INT,  
  commentaires TEXT,
  ordre INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idACTION) REFERENCES ACTION(idACTION),
  FOREIGN KEY(idLIVRABLE) REFERENCES LIVRABLE(idLIVRABLE),  
  PRIMARY KEY(idACTION, idLIVRABLE)
);

/* MESURE */
DROP TABLE IF EXISTS MESURE ;
CREATE TABLE MESURE(
	idMESURE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  idPERSONNE INT,  
  etat TEXT,
  idTMESURES INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idTMESURES) REFERENCES TMESURES(idTMESURES)  
);

/* DEFENDRE */
DROP TABLE IF EXISTS DEFENDRE ;
CREATE TABLE DEFENDRE(
	idMESURE INT,
  idLIGNE INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idMESURE) REFERENCES MESURE(idMESURE),
  FOREIGN KEY(idLIGNE) REFERENCES LIGNE(idLIGNE),  
  PRIMARY KEY(idMESURE, idLIGNE)
);

/* PORTER */
DROP TABLE IF EXISTS PORTER ;
CREATE TABLE PORTER(
	idMESURE INT,
	idBS INT,
	dateCreation DATE,  
    dateModification DATE,
    FOREIGN KEY(idMESURE) REFERENCES MESURE(idMESURE),
    FOREIGN KEY(idBS) REFERENCES BS(idBS),
    PRIMARY KEY(idMESURE, idBS)
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Module 2 */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* ER */
DROP TABLE IF EXISTS ER ;
CREATE TABLE ER(
	idER INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	justification TEXT,
  idCRITERE INT,
  idBE INT,  
  idNCRITERE INT,  
  idNGRISQUE INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE),  
  FOREIGN KEY(idBE) REFERENCES BE(idBE),  
  FOREIGN KEY(idNCRITERE) REFERENCES NCRITERE(idNCRITERE),  
  FOREIGN KEY(idNGRISQUE) REFERENCES NGRISQUE(idNGRISQUE)  
);

/* IMPACT */
DROP TABLE IF EXISTS IMPACT ;
CREATE TABLE IMPACT(
	idIMPACT INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	impactInduit TEXT,
  idTIMPACTS INT,
  dateCreation DATE,  
  dateModification DATE,  
  FOREIGN KEY(idTIMPACTS) REFERENCES TIMPACTS(idTIMPACTS)  
);

/* ENGENDRER */
DROP TABLE IF EXISTS ENGENDRER ;
CREATE TABLE ENGENDRER(
	idCRITERE INT,
  idBE INT,  
  idIMPACT INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE),
  FOREIGN KEY(idBE) REFERENCES BE(idBE),  
  FOREIGN KEY(idIMPACT) REFERENCES IMPACT(idIMPACT),
  PRIMARY KEY(idCRITERE, idBE, idIMPACT)
);

/* INITIER */
DROP TABLE IF EXISTS INITIER ;
CREATE TABLE INITIER(
	idCRITERE INT,
  idBE INT,  
  idSOURCE INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE),
  FOREIGN KEY(idBE) REFERENCES BE(idBE),  
  FOREIGN KEY(idSOURCE) REFERENCES SOURCE(idSOURCE),
  PRIMARY KEY(idCRITERE, idBE, idSOURCE)
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Module 3 */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* SM */
DROP TABLE IF EXISTS SM ;
CREATE TABLE SM(
	idSM INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	justification TEXT,
  idCRITERE INT,
  idBS INT,  
  idNVRISQUE INT,
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idCRITERE) REFERENCES CRITERE(idCRITERE),  
  FOREIGN KEY(idBS) REFERENCES BS(idBS),  
  FOREIGN KEY(idNVRISQUE) REFERENCES NVRISQUE(idNVRISQUE)  
);

/* MENACE */
DROP TABLE IF EXISTS MENACE ;
CREATE TABLE MENACE(
	idMENACE INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  idTMENACES INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idTMENACES) REFERENCES TMENACES(idTMENACES)
);

/* MENACER */
DROP TABLE IF EXISTS MENACER ;
CREATE TABLE MENACER(
  idMENACE INT,
  idSM INT,  
  idNVRISQUE INT,  
  justification TEXT,
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idMENACE) REFERENCES MENACE(idMENACE),
  FOREIGN KEY(idSM) REFERENCES SM(idSM),  
  FOREIGN KEY(idNVRISQUE) REFERENCES NVRISQUE(idNVRISQUE),
  PRIMARY KEY(idMENACE, idSM)
);

/* POUVOIR */
DROP TABLE IF EXISTS POUVOIR ;
CREATE TABLE POUVOIR(
	idSM INT,
  idSOURCE INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idSM) REFERENCES SM(idSM),
  FOREIGN KEY(idSOURCE) REFERENCES SOURCE(idSOURCE),
  PRIMARY KEY(idSM, idSOURCE)
);

/* VULN */
DROP TABLE IF EXISTS VULN ;
CREATE TABLE VULN(
	idVULN INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
  idTVULN INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idTVULN) REFERENCES TVULN(idTVULN)
);

/* EXPLOITER */
DROP TABLE IF EXISTS EXPLOITER ;
CREATE TABLE EXPLOITER(
	idMENACE INT,
  idVULN INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idMENACE) REFERENCES MENACE(idMENACE),
  FOREIGN KEY(idVULN) REFERENCES VULN(idVULN),
  PRIMARY KEY(idMENACE, idVULN)
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Module 4 */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* RISQUE */
DROP TABLE IF EXISTS RISQUE ;
CREATE TABLE RISQUE(
idRISQUE INTEGER PRIMARY KEY AUTOINCREMENT,
  idER INT,
	libelleLong TEXT,
  libelleCourt TEXT,
  graviteBrute INT,
  vraisemblanceBrute INT,
  justificationBrute TEXT,
  graviteME INT,
  vraisemblanceME INT,
  justificationME TEXT,
  graviteMC INT,
  vraisemblanceMC INT,
  justificationMC TEXT,
  objectif INT,
  commentaireObjectif TEXT,
  risqueResiduel TEXT,   
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idER) REFERENCES ER(idER),
  FOREIGN KEY(graviteBrute) REFERENCES NGRISQUE(idNGRISQUE),
  FOREIGN KEY(graviteME) REFERENCES NGRISQUE(idNGRISQUE),  
  FOREIGN KEY(graviteMC) REFERENCES NGRISQUE(idNGRISQUE),
  FOREIGN KEY(vraisemblanceBrute) REFERENCES NVRISQUE(idNVRISQUE),
  FOREIGN KEY(vraisemblanceME) REFERENCES NVRISQUE(idNVRISQUE),  
  FOREIGN KEY(vraisemblanceMC) REFERENCES NVRISQUE(idNVRISQUE),
  FOREIGN KEY(objectif) REFERENCES TOBJECTIFS(idTOBJECTIFS)
);

/* COMPOSER */
DROP TABLE IF EXISTS COMPOSER ;
CREATE TABLE COMPOSER(
	idRISQUE INT,
  idSM INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idRISQUE) REFERENCES RISQUE(idRISQUE),
  FOREIGN KEY(idSM) REFERENCES SM(idSM), 
  PRIMARY KEY(idRISQUE, idSM)
);

/* ASSOCIER */
DROP TABLE IF EXISTS ASSOCIER ;
CREATE TABLE ASSOCIER (
  idNRISQUE INT,
  idNGRISQUE INT,
  idNVRISQUE INT,     
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idNRISQUE) REFERENCES NRISQUE(idNRISQUE),  
  FOREIGN KEY(idNGRISQUE) REFERENCES NGRISQUE(idNGRISQUE),  
  FOREIGN KEY(idNVRISQUE) REFERENCES NVRISQUE(idNVRISQUE),  
  PRIMARY KEY(idNRISQUE, idNGRISQUE, idNVRISQUE)
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Module 5 */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* INDICATEUR */
DROP TABLE IF EXISTS INDICATEUR ;
CREATE TABLE INDICATEUR(
	idINDICATEUR INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	definition TEXT,  
  dateCreation DATE,  
  dateModification DATE
);

/* NINDICATEUR */
DROP TABLE IF EXISTS NINDICATEUR ;
CREATE TABLE NINDICATEUR(
	idNINDICATEUR INTEGER PRIMARY KEY AUTOINCREMENT,
	libelle TEXT,
	description TEXT,
  ordre INT,
  idINDICATEUR INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idINDICATEUR) REFERENCES INDICATEUR(idINDICATEUR)
);

/* CONTRIBUER */
DROP TABLE IF EXISTS CONTRIBUER ;
CREATE TABLE CONTRIBUER(
	idRISQUE INT,
  idMESURE INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idRISQUE) REFERENCES RISQUE(idRISQUE),
  FOREIGN KEY(idMESURE) REFERENCES MESURE(idMESURE), 
  PRIMARY KEY(idRISQUE, idMESURE)
);

/* SUIVRE */
DROP TABLE IF EXISTS SUIVRE ;
CREATE TABLE SUIVRE(
	idMESURE INT,
  idINDICATEUR INT,  
  idNINDICATEUR INT,  
  dateCreation DATE,  
  dateModification DATE,
  FOREIGN KEY(idMESURE) REFERENCES MESURE(idMESURE), 
  FOREIGN KEY(idINDICATEUR) REFERENCES INDICATEUR(idINDICATEUR),
  FOREIGN KEY(idNINDICATEUR) REFERENCES NINDICATEUR(idNINDICATEUR),
  PRIMARY KEY(idMESURE, idINDICATEUR, idNINDICATEUR)
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Fonctionnalités transverses */ 
/* ---------------------------------------------------------------------------------------------------------------------*/

/* ANOMALIE */
DROP TABLE IF EXISTS ANOMALIE ;
CREATE TABLE ANOMALIE (
  idANOMALIE INTEGER PRIMARY KEY AUTOINCREMENT,  
  numero INT,  
  criticite INT,  
  libelle TEXT,  
  etape TEXT,  
  controle INT,
  dateCreation DATETIME  
);

/* ---------------------------------------------------------------------------------------------------------------------*/
/* Jeux de données  de base (intégrée dans la base ANSSI ) */
/* ---------------------------------------------------------------------------------------------------------------------*/

/* tables BK */
INSERT INTO INFORMATION (URL, dateCreation, dateModification) VALUES ("http://www.ssi.gouv.fr/IMG/pdf/EBIOS-1-GuideMethodologique-2010-01-25.pdf",DATE('now'),DATE('now'));

INSERT INTO MODULE (numero, libelle, dateCreation, dateModification) VALUES (1,"Etude du contexte",DATE('now'),DATE('now'));
INSERT INTO MODULE (numero, libelle, dateCreation, dateModification) VALUES (2,"Etude des évènements redoutés",DATE('now'),DATE('now'));
INSERT INTO MODULE (numero, libelle, dateCreation, dateModification) VALUES (3,"Etude des scénarios de menaces",DATE('now'),DATE('now'));
INSERT INTO MODULE (numero, libelle, dateCreation, dateModification) VALUES (4,"Etude des risques",DATE('now'),DATE('now'));
INSERT INTO MODULE (numero, libelle, dateCreation, dateModification) VALUES (5,"Etude des mesures de sécurité",DATE('now'),DATE('now'));

INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (1.1,'Définir le cadre de la gestion des risques',1,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (1.2,'Préparer les métriques',1,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (1.3,'Identifier les biens',1,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (2.1,'Apprécier les évènements redoutés',2,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (3.1,'Apprécier les scénarios de menaces',3,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (4.1,'Apprécier les risques',4,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (4.2,'Identifier les objectifs de sécurité',4,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (5.1,'Formaliser les mesures de sécurité à mettre en oeuvre',5,DATE('now'),DATE('now'));
INSERT INTO ACTIVITE (numero, libelle, idMODULE, dateCreation, dateModification) VALUES (5.2,'Mettre en oeuvre les mesures de sécurité',5,DATE('now'),DATE('now'));

INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.1.1","Cadrer l'étude des risques",1,"purposeView",1,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.1.2","Décrire le contexte général",0,"generalContextView",1,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.1.3","Délimiter le périmètre de l'étude",0,"setPerimeterView",1,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.1.4","Identifier les paramètres à prendre en compte",0,"setParametersView",1,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.1.5","Identifier les sources de menaces",0,"threatSourcesView", 1,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.2.1","Définir les critères de sécurité et élaborer les échelles de besoins",0,"securityCriteriaView",2,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.2.2","Élaborer une échelle de niveaux de gravité",0,"gravityLevelsView",2,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.2.3","Élaborer une échelle de niveaux de vraisemblance",0,"likelihoodLevelsView",2,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.2.4","Définir les critères de gestion des risques",0,"riskManagementCriteriaView",2,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.3.1","Identifier les biens essentiels, leurs relations et leurs dépositaires",0,"primaryAssetsView",3,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.3.2","Identifier les biens supports, leurs relations et leurs propriétaires",0,"supportAssetsView",3,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.3.3","Déterminer le lien entre les biens essentiels et les biens supports",0,"setLinksBetweenAssetsView",3,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("1.3.4","Identifier les mesures de sécurité existantes",0,"securityMeasuresView",3,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("2.1.1","Analyser tous les événements redoutés",0,"fearedEventsView",4,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("2.1.2","Évaluer chaque événement redouté",0,"estimateFearedEventView",4,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("3.1.1","Analyser tous les scénarios de menaces",0,"threatScenariosView",5,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("3.1.2","Évaluer chaque scénario de menace",0,"estimateThreatScenarioView",5,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("4.1.1","Analyser les risques",0,"risksView",6,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("4.1.2","Évaluer les risques",0,"estimateRiskView",6,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("4.2.1","Choisir les options de traitement des risques",0,"chooseManagementRisksOptionView",7,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("4.2.2","Analyser les risques résiduels",0,"estimateResidualRisksView",7,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("5.1.1","Déterminer les mesures de sécurité",0,"defineSecurityMeasuresView",8,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("5.1.2","Analyser les risques résiduels",0,"estimateRedisualRisksView2",8,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("5.1.3","Établir une déclaration d'applicabilité",0,"buildApplicabilityDeclarationView",8,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("5.2.1","Élaborer le plan d'action et suivre la réalisation des mesures de sécurité",0,"designActionPlanView",9,DATE('now'),DATE('now'));
INSERT INTO ACTION (numero, libelle, retenu, vue, idACTIVITE, dateCreation, dateModification) VALUES ("5.2.2","Analyser les risques résiduels",0,"estimateRedisualRisksView3",9,DATE('now'),DATE('now'));

INSERT INTO ROLE (libelle, description, dateCreation, dateModification) VALUES ("Responsable","Responsable de la mise en oeuvre de l'étape", DATE('now'), DATE('now'));
INSERT INTO ROLE (libelle, description, dateCreation, dateModification) VALUES ("Autorité","Autorité légitime pour approuver l'étape", DATE('now'), DATE('now'));
INSERT INTO ROLE (libelle, description, dateCreation, dateModification) VALUES ("Consulté","Consulté pour obtenir les informations nécessaires à l'étape", DATE('now'), DATE('now'));
INSERT INTO ROLE (libelle, description, dateCreation, dateModification) VALUES ("Informé","Informé des résultats de l'étape", DATE('now'), DATE('now'));

INSERT INTO REFERENTIEL (libelle, dateCreation , dateModification) VALUES ("ETUDE", DATE('now'), DATE('now'));
INSERT INTO REFERENTIEL (libelle, description, reference, dateCreation, dateModification) VALUES ("RGS", NULL, "Référentiel général de sécurité – ANSSI (2010).", DATE('now'), DATE('now'));
INSERT INTO REFERENTIEL (libelle, description, reference, dateCreation, dateModification) VALUES ("ISO 27002", NULL, "Information technology – Code of practice for information security management, International Organization for Standardization – ISO (2005).", DATE('now'), DATE('now'));

INSERT INTO LIGNE (libelle, description, dateCreation, dateModification) VALUES ("Prévention", "La ligne préventive est destinée à éviter l'apparition des incidents et des sinistres à l'aide de mesures de sécurité qui agissent sur les sources de menaces (dissuasion, déception…), les besoins de sécurité des biens essentiels (anticipation, prévention…), les vulnérabilités des biens supports (réduction des failles, préparation…).", DATE('now'), DATE('now'));
INSERT INTO LIGNE (libelle, description, dateCreation, dateModification) VALUES ("Protection", "La ligne protectrice est destinée à bloquer, contenir et détecter l'apparition des incidents et des sinistres à l'aide de mesures de sécurité qui agissent sur les besoins de sécurité des biens essentiels (confinement…), les sources de menaces (lutte…),les menaces (détection, protection, réaction défensive…), les vulnérabilités des biens supports (résistance, résilience…).", DATE('now'), DATE('now'));
INSERT INTO LIGNE (libelle, description, dateCreation, dateModification) VALUES ("Récupération", "La ligne récupératrice est destinée à minimiser les conséquences des incidents et des sinistres et revenir à l'état initial, à l'aide de mesures de sécurité qui agissent sur les besoins de sécurité des biens essentiels (récupération, restauration…), les sources de menaces (réaction offensive…), les impacts (compensation…).", DATE('now'), DATE('now'));

INSERT INTO LIVRABLE (libelle, description, trame, produire, dateCreation, dateModification) VALUES ("PSSI", "Politique de sécurité de l'information", "<TITLE>1. Éléments stratégiques</TITLE>
<TITLE>1.1 Périmètre de la PSSI</TITLE>
<OBJECTIF/>
<CONTEXTE/>
<PERIMETRE/>
<TITLE>1.2 Paramètres</TITLE>
<PARAMETRE/>
<TITLE>1.3 Aspects légaux et réglementaires</TITLE>
<TITLE>1.4 Échelle de besoins</TITLE>
<CRITERE_SECURITE/>
<TITLE>1.5 Besoins de sécurite</TITLE>
<TITLE>1.6  Sources de menaces</TITLE>
<SOURCE/>
<TITLE>2. Règles de sécurite</TITLE>
<OPTION_TRT_RISQUE/>
<MATRICE_MESURE_RISQUE/>", NULL, DATE('now'), DATE ('now'));
INSERT INTO LIVRABLE (libelle, description, trame, produire, dateCreation, dateModification) VALUES ("FEROS", "Fiche d'expression rationnelle des objectifs de sécurité", "<TITLE>1. Introduction</TITLE>
<TITLE>1.1 Contexte général</TITLE>
<OBJECTIF/>
<CONTEXTE/>
<TITLE>1.2 Définition des responsabilités</TITLE>
<STRUCTURE_TRAVAIL/>
<TITLE>2. Description du système étudié</TITLE>
<TITLE>2.1 Présentation du système-cible</TITLE>
<PERIMETRE/>
<TITLE>2.2 Description des biens essentiels</TITLE>
<BE/>
<TITLE>2.3 Paramètres</TITLE>
<PARAMETRE/>
<TITLE>2.4 Echelle de besoins</TITLE>
<CRITERE_SECURITE/>
<TITLE>2.5 Besoins de sécurité des biens essentiels</TITLE>
<TITLE>3. Les risques</TITLE>
<TITLE>3.1 Hierarchisation des risques</TITLE>
<CARTO_RISQUE_SM_ME/>
<TITLE>3.2 Description des risques</TITLE>
<RISQUE/>
<TITLE>4. Objectifs de sécurité</TITLE>
<OPTION_TRT_RISQUE/>
<TITLE>5. Les risques résiduels</TITLE>
<TITLE>5.1 Scénario de menaces non retenus</TITLE>
<RISQUE_RESIDUEL/>
<TITLE>5.2 Tableau de couverture des risques par les objectifs</TITLE>
<MATRICE_MESURE_RISQUE/>", NULL, DATE('now'), DATE ('now'));
INSERT INTO LIVRABLE (libelle, description, trame, produire, dateCreation, dateModification) VALUES ("SDSSI", "Schéma directeur SSI", "<TITLE>1. Le volet stratégique</TITLE>
<TITLE>1.2 Les objectifs</TITLE>
<OBJECTIF/>
<CONTEXTE/>
<PERIMETRE/>
<CRITERE_SECURITE/>
<BE_BS/>
<TITLE>1.3 Les impacts</TITLE>
<TITLE>1.4 L'architecture de sécurité des systèmes d'information</TITLE>
<TITLE>1.5 La politique de sécurité mise en oeuvre</TITLE>
<TITLE>2. Le volet opérationnel</TITLE>
<TITLE>2.1 Le référentiel technologique et applicatif</TITLE>
<TITLE>2.2 Le plan d'action</TITLE>
<OPTION_TRT_RISQUE/>
<PLAN_ACTION/>
<TITLE>2.3 Le dispositif de suivi et d'évaluation</TITLE>
<TITLE>2.4 La synthèse économique</TITLE>", NULL, DATE('now'), DATE ('now'));

INSERT INTO CRITERE (libelle, definition, dateCreation, dateModification) VALUES ("Disponibilité", "Propriété d'accessibilité au moment voulu des biens essentiels par les personnes autorisées.", DATE('now'), DATE('now'));
INSERT INTO CRITERE (libelle, definition, dateCreation, dateModification) VALUES ("Intégrité", "Propriété d'exactitude et de complétude des biens essentiels.", DATE('now'), DATE('now'));
INSERT INTO CRITERE (libelle, definition, dateCreation, dateModification) VALUES ("Confidentialité", "Propriété des biens essentiels de n'être accessibles qu'aux personnes autorisés.", DATE('now'), DATE('now'));

INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Plus de 72h", "Le bien essentiel peut être indisponible plus de 72 heures.", 1, 1, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Entre 24h et 72h", "Le bien essentiel doit être disponible dans les 72 heures.", 2, 1, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Entre 4h et 24h", "Le bien essentiel doit être disponible dans les 24 heures.", 3, 1, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Moins de 4h", "Le bien essentiel doit être disponible dans les 4 heures.", 4, 1, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Détectable", "Le bien essentiel peut ne pas être intègre si l'altération est identifiée.", 1, 2, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Maîtrisé", "Le bien essentiel peut ne pas être intègre, si l'altération est identifiée et l'intégrité du bien essentiel retrouvée.", 2, 2, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Intègre", "Le bien essentiel doit être rigoureusement intègre.", 3, 2, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Public", "Le bien essentiel est public.", 1, 3, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Limité", "Le bien essentiel ne doit être accessible qu'au personnel et aux partenaires.", 2, 3, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Réservé", "Le bien essentiel ne doit être accessible qu'au personnel (interne) impliqué.", 3, 3, DATE('now'), DATE('now'));
INSERT INTO NCRITERE (libelle, description, ordre, idCRITERE, dateCreation, dateModification) VALUES ("Privé", "Le bien essentiel ne doit être accessible qu'à des personnes identifiées et ayant le besoin d'en connaître.", 4, 3, DATE('now'), DATE('now'));

INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Locaux", "LOC", "Ce type de biens supports est constitué des infrastructures immobilières hébergeant, et nécessaires au bon fonctionnement, des systèmes informatiques (SYS) et des organisations (ORG), dans lesquels sont utilisés tout ou partie des biens essentiels.", 1, null,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Systèmes informatiques et de téléphonie", "SYS", "Ce type de biens supports est constitué de la combinaison de matériels (MAT), de logiciels (LOG) et de canaux informatiques et de téléphonie (RSX) en interaction, organisés pour élaborer, traiter, stocker, acheminer, présenter ou détruire tout ou partie des biens essentiels.", 2, 1,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Organisations", "ORG", "Ce type de biens supports est constitué de la combinaison de personnes (PER), de supports papier (PAP) et des canaux interpersonnels (CAN) en interaction, organisées pour satisfaire les objectifs d'un organisme (en réalisant des activités métiers spécifiques) et manipulant tout ou partie des biens essentiels.", 3, 1,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Matériels", "MAT", "Ce type de biens supports est constitué de l’ensemble des éléments physiques d'un système informatique (hardware et des supports de données électroniques) participant au stockage et au traitement de tout ou partie des biens essentiels.", 4, 2,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Logiciels", "LOG", "Ce type de biens supports est constitué de l'ensemble des programmes participant au traitement de tout ou partie des biens essentiels (software).", 5, 2,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Canaux réseaux informatiques", "RSX", "Ce type de biens supports est constitué de l'ensemble des vecteurs physiques de communication et de télécommunication qui transportent tout ou partie des biens essentiels.", 6, 2,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Personnes", "PER", "Ce type de biens supports est constitué de l’ensemble des individus, catégories d'individus ou groupes sociaux homogènes, qui ont accès à tout ou partie des biens essentiels.", 7, 3,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Supports papier", "PAP", "Ce type de biens supports est constitué de l’ensemble des Support statique non électronique contenant des données.", 8, 3,DATE('now'), DATE('now'));
INSERT INTO TBS (libelle, titre, description, ordre, idTBSparent, dateCreation , dateModification) VALUES ("Canaux interpersonnels", "CAN", "Ce type de biens supports est constitué de l'ensemble des circuits organisationnels (canaux et processus organisationnels) et des échanges verbaux en face à face, qui transportent tout ou partie des biens essentiels.", 9, 3,DATE('now'), DATE('now'));

INSERT INTO TOBJECTIFS (libelle, definition, ordre, dateCreation , dateModification) VALUES ("Eviter", "Choix de traitement consistant à éviter les situations à risque", 1, DATE('now'), DATE('now'));
INSERT INTO TOBJECTIFS (libelle, definition, ordre, dateCreation , dateModification) VALUES ("Réduire", "Choix de traitement consistant à appliquer des mesures de sécurité destinées à réduire les risques.", 2, DATE('now'), DATE('now'));
INSERT INTO TOBJECTIFS (libelle, definition, ordre, dateCreation , dateModification) VALUES ("Prendre", "Choix de traitement consistant à accepter les conséquences de la réalisation de tout ou partie de risques, sans appliquer de mesure de sécurité.", 3, DATE('now'), DATE('now'));
INSERT INTO TOBJECTIFS (libelle, definition, ordre, dateCreation , dateModification) VALUES ("Transférer", "Choix de traitement consistant à partager les pertes consécutives à la réalisation de risques.", 4, DATE('now'), DATE('now'));

INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M1. MAT-USG – Détournement de l’usage prévu d'un matériel", "Usage d'une imprimante à des fins personnelles au détriment d'autrui, stockage de fichiers personnels sur l'ordinateur de bureau, utilisation de la vitesse de traitement, utilisation de matériels inappropriés à la sensibilité des informations stockées (disque dur, clé USB…).    Critère(s) touché(s): Disponibilité Intégrité Confidentialité", 1, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M2. MAT-ESP – Espionnage d'un matériel", "Observation d'un écran, écoute de hauts parleurs, observation des caractéristiques de fonctionnement d'un matériel (analyse d'émanations électromagnétiques telles que des signaux parasites compromettants issus de l'affichage ou des touches du clavier, observation de caractéristiques électriques telles que la consommation, attaque temporelle, cryptanalyse acoustique, attaque par faute, attaque par perturbation telle qu'un changement rapide de la tension d'alimentation ou au laser, ingénierie inverse), géolocalisation d'un matériel (à partir de son adresse IP ou par le réseau téléphonique), extraction de données par refroidissement brutal (cold boot), interception de signaux compromettants (via des tuyaux ou des câbles de fourniture de ressources, en utilisant une antenne d'interception…).    Critère(s) touché(s): Confidentialité", 2, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M3. MAT-DEP – Dépassement des limites de fonctionnement d'un matériel", "Surexploitation des capacités de stockage et de traitement (surcharge des capacités, volume d’information à traiter supérieur au flux alloué…), exploitation aux limites de fonctionnement (forte sollicitation ou saturation pour provoquer des effets de bord), mise en conditions extrêmes (perturbations électriques ou électromagnétiques, échauffement, glaciation), défaut de fourniture énergétique d'un matériel (surexploitation de l'alimentation électrique par rapport à l'approvisionnement prévu, remplacement de matériels dont la consommation est supérieure à la fourniture énergétique, incompatibilité, surcharge, court-circuit dû à la foudre, une erreur de branchement ou un incident électrique, courant qui disjoncte, rupture de câbles électriques…).    Critère(s) touché(s): Disponibilité", 3, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M4. MAT-DET – Détérioration d'un matériel", "Usure d'un matériel par vieillissement (naturel, accéléré en raison de l’usage de mauvais matériaux, d’une construction défectueuse, de mouvements du terrain, de sape des fondations, d’infiltration d’eau dans le sol…), corrosion (agression chimique, pollution, humidification…), dégradation, casse (vandalisme, code malveillant sollicitant fortement la tête de lecture d'un disque dur), destruction des composants électroniques (impulsion électromagnétique, déclenchement d'une bombe à impulsion électromagnétique ou engendrant un effet électromagnétique), embrasement, explosion (bombe, missile, accident…), effacement d'un matériel (action d'un aimant sur un disque dur, impulsion électromagnétique sur les matériels électroniques, action de vibrations…).    Critère(s) touché(s): Disponibilité", 4, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M5. MAT-MOD – Modification d'un matériel", "Branchement de périphériques ou de supports amovibles incompatibles, changement d'éléments lors d'une maintenance, piégeage d'un matériel (keylogger).    Critère(s) touché(s): Disponibilité Intégrité Confidentialité", 5, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M6. MAT-PTE – Perte d'un matériel", "Vol, perte ou don d'un ordinateur, d'un périphérique, d'un PABX, d'un composant du réseau ou d'un support de données électronique, revente, recyclage ou mise au rebus d'un matériel obsolète, perte de matériel lors d'un déménagement.    Critère(s) touché(s): Disponibilité Confidentialité", 6, 4, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M7. LOG-USG – Détournement de l'usage prévu d'un logiciel", "Lecture ou copie inappropriée via un logiciel : lecture ou copie de données de configuration ou de données métiers, fouille de contenu stocké, collecte de données métiers partagées. Suppression inappropriée via un logiciel : effacement d'enregistrements, de fichiers ou de répertoires, qu'ils soient sur une mémoire, un disque dur ou un support, effacement de traces de journaux d'événements, effacement de fichiers ou de répertoires partagés sur un réseau. Création ou modification inappropriée via un logiciel : saisie de messages ne respectant pas la charte d’utilisation d’un espace d’échange non modéré (forum, blog…), élévation de privilèges d'un compte utilisateur, modification du contenu ou du nom de fichiers ou de répertoires, partagés ou non, ou de la configuration d'un système, qu'ils soient sur une mémoire, un disque dur ou un support (insertion d'une page web sur un site Internet, défiguration de site Internet, élévation de privilèges, modification des traces de journaux d'événements, fraude…), croisement d'informations dont le résultat est confidentiel, utilisation de canaux cachés pour traiter ou véhiculer des données discrètement (stéganographie). Usage inapproprié de fonctionnalités d'un logiciel : usage d'un logiciel professionnel pour des besoins personnels, détournement de fonctionnalités de réseaux (envoi massif d'informations par courrier électronique – spam, envoi de données ou de fichiers partagés, détournement de services d'un réseau…), utilisation de logiciels contrefaits ou copiés.    Critère(s) touché(s): Disponibilité Intégrité Confidentialité", 7, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M8. LOG-ESP – Analyse d'un logiciel", "Collecte de données de configuration d'un réseau, balayage d'adresses réseau ou de ports, observation des caractéristiques de fonctionnement d'un logiciel (observation de l’espace mémoire d’un logiciel depuis un débogueur, ingénierie inverse…).    Critère(s) touché(s): Confidentialité", 8, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M9. LOG-DEP – Dépassement des limites d'un logiciel", "Surexploitation (dépassement du dimensionnement des enregistrements d'une base de données ou de la longueur des variables…), injection de données en dehors des valeurs prévues (fuzzing), attaque en déni de service, lancement d'une boucle infinie, débordement de tampon (buffer overflow), exploitation aux limites de fonctionnement (forte sollicitation ou saturation pour provoquer des effets de bord), saturation des services réseaux, création d'incompatibilités entre logiciels.    Critère(s) touché(s): Disponibilité", 9, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M10. LOG-DET – Suppression de tout ou partie d'un logiciel", "Effacement d'un exécutable en production, effacement de code sources, effacement ou suppression d'un logiciel par un code malveillant (bombe logique…).    Critère(s) touché(s): Disponibilité",10, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M11. LOG-MOD – Modification d'un logiciel", "Manipulation inopportune lors de la mise à jour, de la configuration ou de la maintenance (activation ou désactivation de fonctions, changement de paramétrage du réseau, règles de routage ou de résolution de nom, modification ou ajout de fonctionnalités ou de code…), piégeage logiciel (keylogger, contagion par un code malveillant, substitution d'un composant par un autre…).    Critère(s) touché(s): Disponibilité Intégrité Confidentialité", 11, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M12. LOG-PTE – Disparition d'un logiciel", "Revente d'un logiciel, perte ou non renouvellement de licence, cession de droits sur une licence.    Critère(s) touché(s): Disponibilité Confidentialité", 12, 5, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M13. RSX-USG – Attaque du milieu sur un canal informatique ou de téléphonie", "Attaque du milieu (man in the middle) sur un canal informatique ou téléphonique, rejeu (réémission d'un flux intercepté)…   Critère(s) touché(s): Disponibilité Intégrité", 13, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M14. RSX-ESP – Écoute passive d'un canal informatique ou de téléphonie", "Acquisition de données par écoute passive, interception téléphonique.    Critère(s) touché(s): Confidentialité", 14, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M15. RSX-DEP – Saturation d'un canal informatique ou de téléphonie", "Surexploitation de la bande passante d'un réseau, assourdissement de signal, détournement de la bande passante d'un canal de transmission (exploitation distante d'un réseau sans fil, occupation de bande passante, téléchargement non autorisé…).    Critère(s) touché(s): Disponibilité", 15, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M16. RSX-DET – Dégradation d'un canal informatique ou de téléphonie", "Sectionnement de câblages, dégradation ou coupure d'une ligne téléphonique, pincement de câble, torsion de fibre optique.    Critère(s) touché(s): Disponibilité", 16, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M17. RSX-MOD – Modification d'un canal informatique ou de téléphonie", "Remplacement d'un câble par un autre inapproprié (incompatible, de moins grande capacité…), rallonge de câble, modification du chemin d'un câble, changement de gamme de fréquences hertziennes.    Critère(s) touché(s): Disponibilité", 17, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M18. RSX-PTE – Disparition d'un canal informatique ou de téléphonie", "Vol de câbles de transmission.    Critère(s) touché(s): Disponibilité", 18, 6, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M19. PER-USG – Dissipation de l'activité d'une personne", "Exploitation du temps de travail (réception et tri ou lecture de pourriel – spam, retransmission d'un canular – hoax, retransmission d'une escroquerie – scam…), exploitation d'une personne en dehors de ses prérogatives ou détournement des services rendus par une personne (utilisation illégitime des ressources d'une personne par d'autres services, travail en dehors des missions fixées dans un contrat…), blocage de l'accès d'une personne à son lieu de travail (occupation, grève, squattage, manifestation, routes coupées suite à des inondations, pandémie, zone de guerre, manifestations sur la route d’accès ou blocage du site, zone interdite pour cause de contamination bactérienne, utilisation de locaux à d'autres fins que celles prévues…).    Critère(s) touché(s): Disponibilité", 19, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M20. PER-ESP – Espionnage d'une personne à distance", "Divulgation involontaire, observation du comportement et des habitudes.    Critère(s) touché(s): Confidentialité", 20, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M21. PER-DEP – Surcharge des capacités d'une personne", "Surcharge (une personne est poussée à trop travailler et ne peut plus réaliser ses actions correctement, baisse de performance, fatigue, problèmes personnels…), stress, perturbation des conditions de travail, emploi d'un personnel à une tâche non maîtrisée, mauvaise utilisation des compétences.    Critère(s) touché(s): Disponibilité Intégrité", 21, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M22. PER-DET – Dégradation d'une personne","Accident du travail, maladie professionnelle, autre blessure ou maladie (agression, empoisonnement, intoxication, infection bactériologique, biologique, radiologique, chimique, épidémie, pandémie…), assassinat, décès, surmenage, affection neurologique, psychologique ou psychiatrique, suicide.    Critère(s) touché(s): Disponibilité", 22, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M23. PER-MOD – Influence sur une personne","Pression, corruption ou manipulation (via argent, idéologie, chantage, ego, plaisirs…), hameçonnage, filoutage, ingénierie sociale, harcèlement moral, torture, désinformation, embrigadement, rumeur.    Critère(s) touché(s): Intégrité Confidentialité", 23, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M24. PER-PTE – Départ d'une personne","Départ, changement d'affectation, licenciement, enlèvement, rachat de tout ou partie de l'organisation.    Critère(s) touché(s): Disponibilité Confidentialité", 24, 7, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M25. PAP-USG – Détournement de l’usage prévu d'un support papier", "Falsification d'un support papier (création ou modification du contenu d'un document papier…), effacement de données sur un support papier (usage d'un produit effaçant, disparition de contenus avec le temps…), utilisation du verso d'impressions papier en tant que brouillons ou afin d'économiser le papier.    Critère(s) touché(s): Disponibilité Intégrité", 25, 8, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M26. PAP-ESP – Espionnage d'un support papier", "Lecture de supports papiers, photocopillage, photographie de dossiers papier.    Critère(s) touché(s): Confidentialité",26, 8, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M27. PAP-DET – Détérioration d'un support papier", "Usure d'un support papier par vieillissement (naturel, accéléré en raison de l’usage de mauvais matériaux…), corrosion (agression chimique, pollution, humidification…), dégradation (vandalisme, accident…), embrasement.    Critère(s) touché(s): Disponibilité", 27, 8, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M28. PAP-PTE – Perte d'un support papier", "Vol, perte ou prêt d'un support papier, revente ou mise au rebus d'un document papier, perte de document papier lors d'un déménagement.    Critère(s) touché(s): Disponibilité Confidentialité", 28, 8, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M29. CAN-USG – Manipulation via un canal interpersonnel", "Changement du contenu d'une note dans un circuit courrier, changement d'un parapheur par un autre, disparition d'une note dans un circuit courrier, disparition d'un parapheur, rumeur, désinformation, appropriation de temps de réunion à d'autres fins que celles prévues…    Critère(s) touché(s): Disponibilité Intégrité", 29, 9, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M30. CAN-ESP – Espionnage d'un canal interpersonnel", "Récupération d'information au milieu d'un processus organisationnel, écoute de conversations lors de réunions ou à l'extérieur des locaux, pose d'un microphone dans un bureau.    Critère(s) touché(s): Confidentialité", 30, 9, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M31. CAN-DEP – Saturation d'un canal interpersonnel", "Surcharge d'un processus de validation (ce qui peut mener à une perte ou à un ralentissement du flux d'informations), communication impossible du fait du bruit ambiant.    Critère(s) touché(s): Disponibilité", 31, 9, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M32. CAN-DET – Dégradation d'un canal interpersonnel", "Coupure d'un processus organisationnel du fait d'une réorganisation.    Critère(s) touché(s): Disponibilité", 32, 9, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M33. CAN-MOD – Modification d'un canal interpersonnel", "Évolution inappropriée d'un processus organisationnel, changement de langue professionnelle.    Critère(s) touché(s): Disponibilité", 33, 9, DATE('now'), DATE('now'));
INSERT INTO TMENACES (libelle, exemples, ordre, idTBS, dateCreation , dateModification) VALUES ("M34. CAN-PTE – Disparition d'un canal interpersonnel", "Disparition d'un processus organisationnel lors d'une réorganisation, disparition de réunions d'échanges d'informations.    Critère(s) touché(s): Disponibilité", 34, 9, DATE('now'), DATE('now'));

INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du matériel", 1, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au matériel (franchissement légitime ou non, ou contournement)", 1, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du matériel", 2, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au matériel (franchissement légitime ou non, ou contournement)", 2, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès à la fourniture de ressources essentielles", 3, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Détournement d'usage d'un logiciel pour surcharger les fonctionnalités du matériel", 3, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du matériel", 4, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au matériel (franchissement légitime ou non, ou contournement)", 4, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du matériel", 5, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au matériel (franchissement légitime ou non, ou contournement)", 5, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du matériel", 6, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au matériel (franchissement légitime ou non, ou contournement)", 6, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 7, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès logique au logiciel (franchissement légitime ou non, ou contournement)", 7, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 8, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès logique au logiciel (franchissement légitime ou non, ou contournement)", 8, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 9, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès logique au logiciel (franchissement légitime ou non, ou contournement)", 9, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 10, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 11, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du logiciel", 12, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 13, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 13, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 14, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 14, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 15, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 15, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 16, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 16, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 17, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 17, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 18, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 18, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 19, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Établissement d'une relation (hiérarchique, professionnelle, d'autorité, personnelle, sociale…) avec la personne", 19, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 20, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Proximité physique de la personne", 20, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 21, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Établissement d'une relation (hiérarchique, professionnelle, d'autorité, personnelle, sociale…) avec la personne", 21, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 22, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Proximité physique de la personne", 22, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 23, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Établissement d'une relation (hiérarchique, professionnelle, d'autorité, personnelle, sociale…) avec la personne", 23, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation de la personne", 24, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Établissement d'une relation (hiérarchique, professionnelle, d'autorité, personnelle, sociale…) avec la personne", 24, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du support papier", 25, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au support papier (franchissement légitime ou non, ou contournement)", 25, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du support papier", 26, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au support papier (franchissement légitime ou non, ou contournement)", 26, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du support papier", 27, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au support papier (franchissement légitime ou non, ou contournement)", 27, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du support papier", 28, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique au support papier (franchissement légitime ou non, ou contournement)", 28, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 29, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 29, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 30, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 30, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 31, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 31, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 32, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 32, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 33, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 33, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal interpersonnel", 34, DATE('now'), DATE('now'));
INSERT INTO PREREQUIS (libelle, idTMENACES, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal interpersonnel (intégration légitime ou non d'un élément sur le canal)", 34, DATE('now'), DATE('now'));

INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts issus de l'import d'une étude EBIOSv2", "Impacts issus de l'import d'une étude EBIOSv2", null, 0, DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur les missions", "Conséquences directes ou indirectes sur la réalisation des missions (production d'un bien ou d'un service).", "Incapacité à fournir un service, perte de savoir-faire, changement de stratégie, impossibilité d'assurer un service, conséquences sur la production ou la distribution de biens ou de services considérés comme vitaux (atteinte à la satisfaction des besoins essentiels des populations, à l’exercice de l’autorité de l’État, au fonctionnement de l’économie, au maintien du potentiel de défense, à la sécurité de la nation).", 1,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur la capacité de décision", "Conséquences directes ou indirectes sur la liberté de décider ou diriger.", "Perte de souveraineté, perte ou limitation de l'indépendance de jugement ou de décision, limitation des marges de négociation, perte de capacité d'influence, prise de contrôle de l'organisme.", 2,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur la sécurité des personnes", "Conséquences directes ou indirectes sur l'intégrité physique de personnes.", "Accident du travail, maladie professionnelle, perte de vies humaines, mise en danger.", 3,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur le lien social interne", "Conséquences directes ou indirectes sur la qualité des liens sociaux au sein de l'organisme.", "Perte de confiance des employés dans la pérennité de l'entreprise, exacerbation d'un ressentiment ou de tensions entre groupes sociaux (direction / employés, nationaux / étrangers, fonctionnaires / non- fonctionnaires, jeunes / seniors), affaiblissement de l'engagement d'employés vis-à-vis de l'entreprise, affaiblissement des valeurs éthiques communes au personnel (humanitaire, service public pour tous, progrès social, contribution à la santé dans le monde...).", 4,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur le patrimoine intellectuel ou culturel", "Conséquences directes ou indirectes sur les connaissances non-explicites accumulées par l'organisme, sur le savoir-faire, les capacités d'innovation, sur les références culturelles communes.", "Perte de mémoire de l'entreprise (anciens projets, succès ou échecs...), perte de connaissances implicites (savoir-faire transmis entre générations, optimisations dans l'exécution de tâches ou de processus, captation d'idées novatrices, perte de patrimoine culturel (références esthétiques, modèles, styles...) ou scientifique (espèces biologiques rares ou disparues...).", 5,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts financiers", "Conséquences pécuniaires, directes ou indirectes.", "Perte de chiffre d'affaire, dépenses imprévues, chute de valeur en bourse, baisse de revenus, pénalités.", 6,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur l'image", "Conséquences directes ou indirectes sur l'image de marque, la notoriété, la renommée, la capacité d'influence de l'organisme (lobby, relation avec des acteurs et décideurs politiques ou économiques) ou sur l'éthique (transparence, non corruption, respect de la dignité humaine, argent propre...).", "Publication d'un article satirique dans la presse, perte de crédibilité vis-à-vis de clients, mécontentement des actionnaires, perte d'avance concurrentielle, perte de notoriété.", 7,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts de non-conformité", "Conséquences directes ou indirectes sur l'obtention ou la maintenance d'un label (certification, qualification...) de conformité à des normes.", "Refus d'obtention ou perte de labels du fait de non conformités à l'ISO 27001, Sarbanes-Oxley.", 8,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts juridiques", "Conséquences procédurales, pénales, civiles ou administratives, directes ou indirectes.", "Procès, amende, condamnation d'un dirigeant, dépôt de bilan, avenant, amendements de contrats.", 9,DATE('now'), DATE('now'));
INSERT INTO TIMPACTS (libelle, description, exemples, ordre, dateCreation , dateModification) VALUES ("Impacts sur l'environnement", "Conséquences écologiques à court ou long terme, directes ou indirectes.", "Nuisances dues à des déchets ou des rejets sources de pollution (chimique, bactériologique, radiologique, sonore, visuelle, olfactive, ...) générée par l'organisme et touchant son périmètre, son voisinage ou une zone.", 10,DATE('now'), DATE('now')); 

INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-USG – Détournement de l’usage prévu d'un matériel", 1, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-ESP – Espionnage d'un matériel", 2, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-DEP – Dépassement des limites de fonctionnement d'un matériel", 3, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-DET – Détérioration d'un matériel", 4, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-MOD – Modification d'un matériel", 5, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("MAT-PTE – Perte d'un matériel", 6, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-USG – Détournement de l'usage prévu d'un logiciel", 7, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-ESP – Analyse d'un logiciel", 8, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-DEP – Dépassement des limites d'un logiciel", 9, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-DET – Suppression de tout ou partie d'un logiciel", 10, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-MOD – Modification d'un logiciel", 11, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("LOG-PTE – Disparition d'un logiciel", 12, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-USG – Attaque du milieu sur un canal informatique ou de téléphonie", 13, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-ESP – Écoute passive d'un canal informatique ou de téléphonie", 14, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-DEP – Saturation d'un canal informatique ou de téléphonie", 15, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-DET – Dégradation d'un canal informatique ou de téléphonie", 16, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-MOD – Modification d'un canal informatique ou de téléphonie", 17, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("RSX-PTE – Disparition d'un canal informatique ou de téléphonie", 18, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-USG – Dissipation de l'activité d'une personne", 19, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-ESP – Espionnage d'une personne à distance", 20, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-DEP – Surcharge des capacités d'une personne", 21, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-DET – Dégradation d'une personne", 22, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-MOD – Influence sur une personne", 23, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PER-PTE – Départ d'une personne", 24, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PAP-USG – Détournement de l’usage prévu d'un support papier", 25, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PAP-ESP – Espionnage d'un support papier", 26, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PAP-DET – Détérioration d'un support papier", 27, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("PAP-PTE – Perte d'un support papier", 28, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-USG – Manipulation via un canal interpersonnel", 29, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-ESP – Espionnage d'un canal interpersonnel", 30, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-DEP – Saturation d'un canal interpersonnel", 31, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-DET – Dégradation d'un canal interpersonnel", 32, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-MOD – Modification d'un canal interpersonnel", 33, DATE('now'), DATE('now'));
INSERT INTO TVULN (libelle, ordre, dateCreation , dateModification) VALUES ("CAN-PTE – Disparition d'un canal interpersonnel", 33, DATE('now'), DATE('now'));

INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, malveillante, avec de faibles capacités", "Collaborateur malveillant avec des possibilités d'action limitées sur le système d'information (personnel en fin de contrat ou voulant se venger de son employeur ou de ses collègues...), stagiaire agissant de manière ludique, client désirant obtenir des avantages, personnel d'entretien.", 1, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, malveillante, avec des capacités importantes", "Collaborateur malveillant avec d'importantes connaissances et possibilités d'action sur le système d'information (manager ambitieux en fin de contrat ou voulant se venger de son employeur ou de ses collègues, développeur agissant par égo ou de manière ludique, fraudeur, actionnaires...), sous- traitant ou prestataire, personnel de maintenance ou d'assistance à distance.", 2, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, malveillante, avec des capacités illimitées", "Collaborateur malveillant avec des connaissances et possibilités d'action illimitées sur le système d'information (administrateur système ou réseau agissant par vengeance, dirigeant...).", 3, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, malveillante, avec de faibles capacités", "Script-kiddies, vandale.", 4, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, malveillante, avec des capacités importantes", "Militant agissant de manière idéologique ou politique, pirate passionné, casseur ou fraudeur, ancien employé désirant se venger d'un licenciement, concurrent, groupement professionnel, organisation de lobbying, syndicat, journaliste, organisation non gouvernementale.", 5, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, malveillante, avec des capacités illimitées", "Organisation criminelle, agence gouvernementale ou organisation sous le contrôle d'un État étranger, espions, organisation terroriste.", 6, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, sans intention de nuire, avec de faibles capacités", "Collaborateur maladroit ou inconscient avec des possibilités d'action limitées sur le système d'information, personnel à faible conscience d'engagement, peu sensibilisé ou peu motivé dans sa relation contractuelle avec l'organisme, personnel d'entretien maladroit, stagiaire, thésard, intérimaire, utilisateur, fournisseur, prestataire, sous-traitant, client, actionnaires.", 7, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, sans intention de nuire, avec des capacités importantes", "Collaborateur maladroit ou inconscient avec d'importantes connaissances et possibilités d'action sur le système d'information (manager, développeur...).", 8, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine interne, sans intention de nuire, avec des capacités illimitées", "Collaborateur maladroit ou inconscient avec des connaissances et possibilités d'action illimitées sur le système d'information (administrateur système ou réseau, dirigeant...).", 9, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, sans intention de nuire, avec de faibles capacités", "Entourage du personnel, personne réalisant des travaux dans le voisinage, manifestants, visiteur maladroit, forte ambiance sonore.", 10, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, sans intention de nuire, avec des capacités importantes", "Matériels émettant des ondes, des vibrations, activités industrielles dégageant des substances chimiques toxiques ou susceptibles de provoquer des sinistres mineurs, trafic routier ou aérien pouvant générer des accidents.", 11, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Source humaine externe, sans intention de nuire, avec des capacités illimitées", "Matériels émettant des radiations ou des impulsions électromagnétiques, activités industrielles susceptibles de provoquer des sinistres majeurs, explosion dans le voisinage.", 12, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Code malveillant d'origine inconnue", "Virus informatique, code malveillant non ciblé, ou ciblé mais d'origine inconnue.", 13, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Phénomène naturel", "Phénomène météorologique ou climatique aléatoire (foudre, canicule...), chute de roches, infiltration de sable, usure (temps qui s'écoule), phénomène naturel imprévisible mais récurrent.", 14, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Catastrophe naturelle ou sanitaire", "Phénomène géologique (affaissement de terrain, séisme, éruption volcanique...), météorologique (tempête, ouragan...), naturel (feu de forêt, crue...), sanitaire (pandémie) de grande ampleur.", 15, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Activité animale", "Présence d'animaux susceptibles de provoquer des dégâts aux infrastructures (rongeurs...), présence d'animaux dangereux pour l'homme.", 16, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TSOURCES (libelle, exemples, ordre, retenu, justification, dateCreation , dateModification) VALUES ("Événement interne", "Présence de matières corrosives, combustion de matières inflammables, incendie des locaux, explosion de matières explosives, fuite de canalisation, accident de chantier, fuite de substances chimiques, réorganisation, changement d'architecture réseau, branchement d'un composant réseau ou d'une machine incompatible, travaux de réaménagement des locaux.", 17, 0, NULL, DATE('now'), DATE('now'));

INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Paramètres issus de l'import d'une étude EBIOSv2" , NULL, 0, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Références communautaires, légales et réglementaires à appliquer", NULL, 1, 0, NULL, DATE('now'), DATE ('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Références internes relatives à la sécurité de l'information à appliquer", "Politiques de sécurité (globale, de l'information, du système d'information, du patrimoine informationnel…) ou documents d'application (politiques locales, procédures…), schémas directeurs traitant de sécurité de l'information, plans de continuité (des activités, des applications…), de secours ou de reprise, résultats d'audits relatifs à la sécurité de l'information…", 2, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes de conformité à des référentiels", "ISO 27001, homologations…", 3, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'ordre politique", "Par exemple, le principe de dématérialisation des factures ou des documents administratifs induit des problèmes de sécurité.", 4, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'ordre stratégique", "Par exemple, les coopérations internationales sur la mise en commun d'informations sensibles peuvent nécessiter des accords au niveau des échanges sécurisés.", 5, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes territoriales", "Par exemple, les agences de la poste, les ambassades, les banques, les différentes filiales d'un grand groupe industriel...", 6, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes conjoncturelles", "Par exemple, la continuité de certains services doit pouvoir être assurée même en période de crise grave.", 7, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes structurelles", "Par exemple, une structure internationale doit pouvoir concilier des exigences de sécurité propres à chaque nation.", 8, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes fonctionnelles", "Par exemple, un organisme peut avoir une mission de permanence qui exigera une disponibilité maximale de ses moyens.", 9, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes relatives au personnel", "Par exemple, il peut être nécessaire que l'ensemble du personnel d'un organisme de la défense soit habilité pour des confidentialités supérieures.", 10, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'ordre calendaire", "Par exemple, la création d’une direction de la sécurité.", 11, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes relatives aux méthodes", "La contrainte peut être, par exemple, de devoir associer la politique de sécurité aux actions relatives à la qualité, en vigueur dans l'organisme.", 12, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'ordre culturel", "Caractères, éducation, instruction, expérience professionnelle ou extra-professionnelle, opinions, philosophie, croyances, sentiments, statut social…", 13, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'ordre budgétaire", "Par exemple, dans le secteur privé et pour certains organismes publics, le coût total des mesures de sécurité ne doit pas être supérieur aux conséquences des risques redoutés. La direction doit donc apprécier et prendre des risques calculés si elle veut éviter un coût prohibitif pour la sécurité.", 14, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'antériorité", "Un système peut faire l'objet d'une décomposition en sous-systèmes , un système n'est pas forcément conditionné par la totalité des sous-systèmes (par extension à des fonctions d'un système) d'un autre système.", 15, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes techniques", "Elles peuvent provenir des fichiers (exigences en matière d'organisation, de gestion de supports, de gestion des règles d'accès…), de l'architecture générale (exigences en matière de topologie, qu'elle soit centralisée, répartie, distribuée, ou de type client-serveur, d'architecture physique…), des logiciels applicatifs (exigences en matière de conception des logiciels spécifiques, de standards du marché…), des progiciels (exigences de standards, de niveau d'évaluation, qualité, conformité aux normes, sécurité…), des matériels (exigences en matière de standards, qualité, conformité aux normes…), des réseaux de communication (exigences en matière de couverture, de standards, de capacité, de fiabilité…), des infrastructures immobilières (exigences en matière de génie civil, construction des bâtiments, courants forts, courants faibles…)…", 16, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes financières", "Budget", 17, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes d'environnement", "Pays, climat, risques naturels, situation géographique, conjoncture économique…", 18, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes de temps", NULL, 19, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes relatives aux méthodes", NULL, 20, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Contraintes organisationnelles", "L'exploitation (exigences en matière de délais, de fourniture de résultats, de services, exigences de surveillance, de suivi, de plans de secours, fonctionnement en mode dégradé…), la maintenance (exigences d'actions de diagnostic d'incidents, de prévention, de correction rapide…), la gestion des ressources humaines (exigences en matière de formation des opérationnels et des utilisateurs, de qualification pour l'occupation des postes tels qu'administrateur système ou administrateur de données…), la gestion administrative (exigences en matière de responsabilités des acteurs…), la gestion des développements (exigences en matière d'outils de développement, AGL, de plans de recette, d'organisation à mettre en place…), la gestion des relations externes (exigences en matière d'organisation des relations tierces, en matière de contrats…)…", 21, 0, NULL, DATE('now'), DATE('now'));
INSERT INTO TPARAMETRES (libelle, exemples, ordre, retenu, justification, dateCreation, dateModification) VALUES ("Hypothèses", NULL, 22, 0, NULL, DATE('now'), DATE('now'));

INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 1, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 1, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 1, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 2, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 3, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 4, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 5, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 5, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 5, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 6, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 6, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 7, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 7, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 7, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 8, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 9, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 10, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 11, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 11, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 11, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 12, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 12, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 13, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 13, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 14, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 15, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 16, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 17, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 18, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 19, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 20, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 21, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 21, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 22, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 23, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 23, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 24, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 24, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 25, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 25, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 26, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 27, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 28, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 28, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 29, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (2, 29, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (3, 30, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 31, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 32, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 33, DATE ('now'), DATE('now'));
INSERT INTO AFFECTER (idCRITERE, idTMENACES, dateCreation, dateModification) VALUES (1, 34, DATE ('now'), DATE('now'));

INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (1,1,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (2,2,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (3,3,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (4,4,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (5,5,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (6,6,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (7,7,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (8,8,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (9,9,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (10,10,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (11,11,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (12,12,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (13,13,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (14,14,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (15,15,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (16,16,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (17,17,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (18,18,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (19,19,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (20,20,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (21,21,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (22,22,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (23,23,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (24,24,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (25,25,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (26,26,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (27,27,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (28,28,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (29,29,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (30,30,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (31,31,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (32,32,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (33,33,DATE('now'), DATE('now'));
INSERT INTO PROFITER (idTMENACES, idTVULN, dateCreation , dateModification) VALUES (34,34,DATE('now'), DATE('now'));

INSERT INTO STATUT (libelle, dateCreation , dateModification) VALUES ("Non retenu", DATE('now'), DATE('now'));
INSERT INTO STATUT (libelle, dateCreation , dateModification) VALUES ("Satisfait", DATE('now'), DATE('now'));
INSERT INTO STATUT (libelle, dateCreation , dateModification) VALUES ("Prévu", DATE('now'), DATE('now'));
INSERT INTO STATUT (libelle, dateCreation , dateModification) VALUES ("Non satisfait", DATE('now'), DATE('now'));
INSERT INTO STATUT (libelle, dateCreation , dateModification) VALUES ("Non applicable", DATE('now'), DATE('now'));

INSERT INTO NRISQUE (libelle, codeCouleur, dateCreation , dateModification) VALUES ("Risques négligeables", "0xFFFFFF", DATE('now'), DATE('now'));
INSERT INTO NRISQUE (libelle, codeCouleur, dateCreation , dateModification) VALUES ("Risques significatifs", "0xFFFFFF", DATE('now'), DATE('now'));
INSERT INTO NRISQUE (libelle, codeCouleur, dateCreation , dateModification) VALUES ("Risques intolérables", "0xFFFFFF", DATE('now'), DATE('now'));

INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("Mesures issues de l'import d'une étude EBIOSv2", NULL, NULL,1,1, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("Mesures issues d'un référentiel", NULL, NULL,2,1, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("Mesures de l'étude", NULL, NULL,3,1, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("2. Un cadre pour gérer la sécurité des systèmes d'information", NULL, NULL,4,2, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("2.2. Six grands principes de gestion de la SSI", NULL, NULL,5,2,4, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("2.3. Intégration de la SSI dans le cycle de vie des systèmes d'information", NULL, NULL,6,2,4, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("3. Fonctions de sécurité", NULL, NULL,7,2, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("3.2. Authentification", NULL, NULL,8,2,7, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("3.3. Signature électronique", NULL, NULL,9,2,7, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("3.4. Confidentialité", NULL, NULL,10,2,7, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("3.5. Horodatage", NULL, NULL,11,2,7, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("4. Accusé d’enregistrement et de réception", NULL, NULL,12,2, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("4.2. Règles de sécurité", NULL, NULL,13,2,12, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("5. Qualification", NULL, NULL,14,2, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("5.1. Qualification de produits de sécurité", NULL, NULL,15,2,14, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6. Les infrastructures de gestion de clés (IGC)", NULL, NULL,16,2, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6.1. Règles et recommandations générales", NULL, NULL,17,2,16, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6.2. Cas particulier de la validation des certificats par l’État", NULL, NULL,18,2,16, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("5. Politique de sécurite", NULL, NULL,19,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("5.1. Politique de sécurité de l'information", NULL, NULL,20,3,19, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6. Organisation de la sécurité de l’information", NULL, NULL,21,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6.1. Organisation interne", NULL, NULL,22,3,21, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("6.2. Tiers", NULL, NULL,23,3,21, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("7. Gestion des biens", NULL, NULL,24,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("7.1. Responsabilités relatives aux biens", NULL, NULL,25,3,24, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("7.2. Classification des informations", NULL, NULL,26,3,24, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("8. Sécurité liée aux ressources humaines", NULL, NULL,27,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("8.1. Avant le recrutement", NULL, NULL,28,3,27, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("8.2. Pendant la durée du contrat", NULL, NULL,29,3,27, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("8.3. Fin ou modification de contrat", NULL, NULL,30,3,27, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("9. Sécurité physique et environnementale", NULL, NULL,31,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("9.1. Zones sécurisées", NULL, NULL,32,3,31, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("9.2. Sécurité du matériel", NULL, NULL,33,3,31, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10. Gestion de l'exploitation et des télécommunications", NULL, NULL,34,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.1. Procédures et responsabilités liées à l’exploitation", NULL, NULL,35,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.2. Gestion de la prestation de service par un tiers", NULL, NULL,36,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.3. Planification et acceptation du système", NULL, NULL,37,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.4. Protection contre les codes malveillant et mobile", NULL, NULL,38,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.5. Sauvegarde", NULL, NULL,39,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.6. Gestion de la sécurité des réseaux", NULL, NULL,40,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.7. Manipulation des supports", NULL, NULL,41,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.8. Échange des informations", NULL, NULL,42,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.9. Services de commerce électronique", NULL, NULL,43,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("10.10. Surveillance", NULL, NULL,44,3,34, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11. Contrôle d’accès", NULL, NULL,45,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.1. Exigences métier relatives au contrôle d’accès", NULL, NULL,46,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.2. Gestion de l’accès utilisateur", NULL, NULL,47,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.3. Responsabilités utilisateurs", NULL, NULL,48,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.4. Contrôle d’accès au réseau", NULL, NULL,49,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.5. Contrôle d’accès au système d’exploitation", NULL, NULL,50,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.6. Contrôle d’accès aux applications et à l’information", NULL, NULL,51,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("11.7. Informatique mobile et télétravail", NULL, NULL,52,3,45, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12. Acquisition, développement et maintenance des systèmes d’information", NULL, NULL,53,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.1. Exigences de sécurité applicables aux systèmes d’information", NULL, NULL,54,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.2. Bon fonctionnement des applications", NULL, NULL,55,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.3. Mesures cryptographiques", NULL, NULL,56,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.4. Sécurité des fichiers système", NULL, NULL,57,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.5. Sécurité en matière de développement et d’assistance technique", NULL, NULL,58,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("12.6. Gestion des vulnérabilités techniques", NULL, NULL,59,3,53, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("13. Gestion des incidents liés à la sécurité de l’information", NULL, NULL,60,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("13.1. Signalement des événements et des failles liés à la sécurité de l’information", NULL, NULL,61,3,60, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("13.2. Gestion des améliorations et incidents liés à la sécurité de l’information", NULL, NULL,62,3,60, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("14. Gestion du plan de continuité de l'activite", NULL, NULL,63,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("14.1. Aspects de la sécurité de l’information en matière de gestion de la continuité de l’activite", NULL, NULL,64,3,63, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("15. Conformité", NULL, NULL,65,3, null, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("15.1. Conformité avec les exigences légales", NULL, NULL,66,3,65, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("15.2. Conformité avec les politiques et normes de sécurité et conformité technique", NULL, NULL,67,3,65, DATE('now'), DATE('now'));
INSERT INTO TMESURES (libelle, description, exemples, ordre, idREFERENTIEL, idTMESURESparent, dateCreation , dateModification) VALUES ("15.3. Prises en compte de l’audit du système d’information", NULL, NULL,68,3,65, DATE('now'), DATE('now'));

INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Adopter une démarche globale", NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Adapter la SSI selon les enjeux", NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gérer les risques SSI",NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Élaborer une politique SSI", NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utiliser les produits et prestataires labellisés SSI", NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Viser une amélioration continue", NULL,NULL,5,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Des efforts proportionnés aux enjeux SSI", NULL,NULL,6,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Un engagement systématique: l'homologation de sécurité", NULL,NULL,6,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Des outils ciblés pour les projets de système d’information", NULL,NULL,6, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation de mécanismes cryptographiques", NULL,NULL,8,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation des identifiants / mots de passe statiques", NULL,NULL,8,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Authentification d’une personne par certificat électronique", NULL,NULL,8,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Authentification d’un serveur par certificat électronique", NULL,NULL,8,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation de mécanismes cryptographiques", NULL,NULL,9,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Signature d’une personne par certificat électronique", NULL,NULL,9,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Cachet d’un serveur par certificat électronique", NULL,NULL,9,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation de mécanismes cryptographiques", NULL,NULL,10,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Confidentialité par certificat électronique", NULL,NULL,10,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Habilitations", NULL,NULL,10,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation des mécanismes cryptographiques", NULL,NULL,11,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Horodatage par contremarques de temps", NULL,NULL,11,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Règles de sécurité", NULL,NULL,13,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Qualification élémentaire", NULL,NULL,15,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Qualification standard", NULL,NULL,15,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Qualification renforcée", NULL,NULL,15,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Règles et recommandations générales", NULL,NULL,17,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Règles de sécurité", NULL,NULL,18,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Document de politique de sécurité de l’information", NULL,NULL,20,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Réexamen de la politique de sécurité de l’information", NULL,NULL,20,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Engagement de la direction vis-à-vis de la sécurité de l'information", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Coordination de la sécurité de l'information", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Attribution des responsabilités en matière de sécurité de l'information", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Système d'autorisation concernant les moyens de traitement de l'information", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Engagements de confidentialité", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Relations avec les autorités", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Relations avec des groupes de spécialistes", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Revue indépendante de la sécurité de l'information", NULL,NULL,22,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Identification des risques provenant des tiers", NULL,NULL,23,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("La sécurité et les clients", NULL,NULL,23,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("La sécurité dans les accords conclus avec des tiers", NULL,NULL,23,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Inventaire des biens", NULL,NULL,25,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Propriété des biens", NULL,NULL,25,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation correcte des biens",NULL,NULL,25,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Lignes directrices pour la classification", NULL,NULL,26,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Marquage et manipulation de l’information", NULL,NULL,26,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Rôles et responsabilités", NULL,NULL,28,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sélection", NULL,NULL,28, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Conditions d’embauche", NULL,NULL,28, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Responsabilités de la direction", NULL,NULL,29,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sensibilisation, qualification et formations en matière de sécurité de l'information", NULL,NULL,29,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Processus disciplinaire", NULL,NULL,29, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Responsabilités en fin de contrat", NULL,NULL,30,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Restitution des biens", NULL,NULL,30,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Retrait des droits d'accès", NULL,NULL,30,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Périmètre de sécurité physique", NULL,NULL,32,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Contrôles physiques des accès", NULL,NULL,32,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sécurisation des bureaux, des salles et des équipements", NULL,NULL,32,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection contre les menaces extérieures et environnementales", NULL,NULL,32, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Travail dans les zones sécurisées", NULL,NULL,32, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Zones d'accès public, de livraison et de chargement", NULL,NULL,32, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Choix de l'emplacement et de protection du matériel", NULL,NULL,33,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Services généraux", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sécurité du câblage", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Maintenance du matériel", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sécurité du matériel hors des locaux", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mise au rebut ou recyclage sécurisé(e) du matériel", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sortie d'un bien", NULL,NULL,33, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Procédures d'exploitation documentées", NULL,NULL,35,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion des modifications", NULL,NULL,35,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Séparation des tâches", NULL,NULL,35,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Séparation des équipements de développement, de test et d'exploitation", NULL,NULL,35,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Prestation de service", NULL,NULL,36,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Surveillance et réexamen des services tiers", NULL,NULL,36,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion des modifications dans les services tiers", NULL,NULL,36,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Dimensionnement", NULL,NULL,37,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Acceptation du système", NULL,NULL,37,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesures contre les codes malveillants", NULL,NULL,38,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesures contre le code mobile", NULL,NULL,38,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sauvegarde des informations", NULL,NULL,39,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesures sur les réseaux", NULL,NULL,40,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sécurité des services réseau", NULL,NULL,40,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion des supports amovibles", NULL,NULL,41,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mise au rebut des supports", NULL,NULL,41,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Procédures de manipulation des informations", NULL,NULL,41,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Sécurité de la documentation système", NULL,NULL,41,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Politiques et procédures d'échange des informations", NULL,NULL,42,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Accords d'échange", NULL,NULL,42,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Supports physiques en transit", NULL,NULL,42,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Messagerie électronique", NULL,NULL,42,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Systèmes d'information d'entreprise", NULL,NULL,42,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Commerce électronique", NULL,NULL,43,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Transactions en ligne", NULL,NULL,43,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Informations à disposition du public", NULL,NULL,43,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Rapport d'audit", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Surveillance de l'exploitation du système", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des informations journalisées", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Journal administrateur et journal des opérations", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Rapports de défaut", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Synchronisation des horloges", NULL,NULL,44,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Politique de contrôle d'accès", NULL,NULL,46,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Enregistrement des utilisateurs", NULL,NULL,47,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion des privilèges", NULL,NULL,47,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion du mot de passe utilisateur", NULL,NULL,47,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Réexamen des droits d'accès utilisateurs", NULL,NULL,47,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Utilisation du mot de passe", NULL,NULL,48,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Matériel utilisateur laissé sans surveillance", NULL,NULL,48,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Politique de bureau propre et de l'écran vide", NULL,NULL,48,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Politique relative à l'utilisation des services en réseau", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Authentification de l'utilisateur pour les connexions externes", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Identification des matériels en réseau", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des ports de diagnostic et de configuration à distance", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Cloisonnement des réseaux", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesure relative à la connexion réseau", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Contrôle du routage réseau", NULL,NULL,49,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Ouverture de sessions sécurisées", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Identification et authentification de l'utilisateur", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Système de gestion des mots de passe", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Emploi des utilitaires système", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Déconnexion automatique des sessions inactives", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Limitation du temps de connexion", NULL,NULL,50,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Restriction d'accès à l'information", NULL,NULL,51,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Isolement des systèmes sensibles", NULL,NULL,51,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Informatique mobile et télécommunications", NULL,NULL,52,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Télétravail", NULL,NULL,52,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Analyse et spécification des exigences de sécurité", NULL,NULL,54,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Validation des données d'entrée", NULL,NULL,55,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesure relative au traitement interne", NULL,NULL,55,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Intégrité des messages", NULL,NULL,55,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Validation des données en sortie", NULL,NULL,55,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Politique d'utilisation des mesures cryptographiques", NULL,NULL,56,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Gestion des clés", NULL,NULL,56,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesure relative aux logiciels en exploitation", NULL,NULL,57,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des données système d'essai", NULL,NULL,57,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Contrôle d'accès au code source du programme", NULL,NULL,57,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Procédures de contrôle des modifications", NULL,NULL,58,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Réexamen technique des applications après modification du système d'exploitation", NULL,NULL,58,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Restrictions relatives à la modification des progiciels", NULL,NULL,58,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Fuite d'informations", NULL,NULL,58,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Externalisation du développement logiciel", NULL,NULL,58,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesure relative aux vulnérabilités techniques", NULL,NULL,59,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Signalement des évènements liés à la sécurité de l'information", NULL,NULL,61,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Signalement des failles de sécurité", NULL,NULL,61,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Responsabilités et procédures", NULL,NULL,62,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Exploitation des incidents liés à la sécurité de l'information déjà survenus", NULL,NULL,62,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Collecte de preuves", NULL,NULL,62,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Intégration de la sécurité de l'information dans le processus de gestion du plan de continuité de l'activité", NULL,NULL,64,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Continuité de l'activité et appréciation du risque", NULL,NULL,64,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Elaboration et mise en oeuvre des plans de continuité intégrant la sécurité de l'information", NULL,NULL,64,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Cadre de la planification de la continuité de l'activité", NULL,NULL,64,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mise à l'essai, gestion et appréciation constante des plans de continuité de l'activité", NULL,NULL,64, DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Identification de la législation en vigueur", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Droits de propriété intellectuelle", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des enregistrements de l'organisme", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des données et confidentialité des informations relatives à la vie privée", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Mesure préventive à l'égard du mauvais usage des moyens de traitement de l'information", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Règlementation relative aux mesures cryptographiques", NULL,NULL,66,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Conformité avec les politiques et les normes de sécurité", NULL,NULL,67,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Vérification de la conformité technique", NULL,NULL,67,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Contrôles de l'audit du système d'information", NULL,NULL,68,DATE('now'), DATE('now'));
INSERT INTO MESURE (libelle, idPERSONNE, etat, idTMESURES, dateCreation , dateModification) VALUES ("Protection des outils d'audit du système d'information", NULL,NULL,68,DATE('now'), DATE('now'));

/* autres tables */
INSERT INTO ETUDE (but, butBrut, diversContexte, diversContexteBrut, diversPerimetre, diversPerimetreBrut, dateCreation, dateModification) VALUES ("Le but de l'étude est ...", "Le but de l'étude est ...", "Le contexte de l'étude ...", "Le contexte de l'étude ...", "Le périmètre de l'étude est ...", "Le périmètre de l'étude est ...", DATE('now'),DATE('now'));   

INSERT INTO NGRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Non retenu", "Non retenu", 0, DATE('now'), DATE('now'));
INSERT INTO NGRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Négligeable", "Gravité négligeable", 1, DATE('now'), DATE('now'));
INSERT INTO NGRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Limitée", "Gravité limitée", 2, DATE('now'), DATE('now'));
INSERT INTO NGRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Importante", "Gravité importante", 3, DATE('now'), DATE('now'));
INSERT INTO NGRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Critique", "Gravité critique", 4, DATE('now'), DATE('now'));

INSERT INTO NVRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Non retenu", "Non retenu", 0, DATE('now'), DATE('now'));
INSERT INTO NVRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Minime", "Minime", 1, DATE('now'), DATE('now'));
INSERT INTO NVRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Significative", "Significative", 2, DATE('now'), DATE('now'));
INSERT INTO NVRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Forte", "Forte", 3, DATE('now'), DATE('now'));
INSERT INTO NVRISQUE(libelle, description, ordre, dateCreation , dateModification) VALUES ("Maximale", "Maximale", 4, DATE('now'), DATE('now'));

INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Utilisable en dehors de l'usage prévu (exploitation nominale des biens essentiels)", 1, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'observer des données interprétables", 2, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Émet des signaux compromettants", 2, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Dimensionnement inapproprié des capacités de stockage", 3, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Dimensionnement inapproprié des capacités de traitement", 3, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("N'est pas approprié aux conditions d'utilisation", 3, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Requiert en permanence de l'électricité pour fonctionner", 3, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Sensible aux variations de tension", 3, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Composants de mauvaise facture (fragile, facilement inflammable, sujet au vieillissement…)", 4, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("N'est pas approprié aux conditions d'utilisation (sensible à l'humidité…)", 4, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Effaçable (vulnérable aux effets électromagnétiques ou vibratoires…)", 4, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'ajouter, retirer ou substituer des éléments (cartes, extensions…) via des connecteurs (ports, slots…)", 5, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de désactiver des éléments (port USB…)", 5, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Portable", 6, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Attractif (valeur marchande)", 6, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Donne accès à des données", 7, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de manipuler des données (supprimer, modifier, déplacer…)", 7, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Peut être détourné de son usage nominal (offre la possibilité d’envois massifs…)", 7, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'utiliser des fonctionnalités avancées", 7, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Accessibilité et intelligibilité du code source", 8, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Possibilité d'observer le fonctionnement du logiciel", 8, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de saisir n'importe quelle donnée", 9, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de saisir n'importe quel volume de données", 9, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de réaliser n'importe quelle action avec les données entrantes", 9, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Peu interopérable", 9, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Possibilité d'effacer ou de supprimer des programmes", 10, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Exemplaire unique", 10, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Utilisation complexe (mauvaise ergonomie, peu d'explications…)", 10, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Modifiable (améliorable, paramétrable…)", 11, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Maîtrise insuffisante par les développeurs ou les mainteneurs (spécifications incomplètes, peu de compétences internes…)", 11, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Ne fonctionne pas correctement ou conformément aux attentes", 11, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Exemplaire unique (des contrats de licence ou du logiciel, développé en interne…)", 12, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Attractif (rare, novateur, grande valeur commerciale…)", 12, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Cessible (clause de cessibilité totale dans la licence…)", 12, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'altérer les flux communiqués (interception puis réémission, éventuellement après altération…)", 13, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Seule ressource de transmission pour le flux", 13, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet de modifier les règles de partage du canal informatique ou de téléphonie (protocole de transmission qui autorise le rajout de noeuds et l'accès…)", 13, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Unique", 14, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Perméable (émission de rayonnements, parasites ou non…)", 14, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'observer des données interprétables", 14, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Observable", 14, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Dimensionnement fixe des capacités de transmission (dimensionnement insuffisant de la bande passante, plage de numéros téléphoniques limitée…)", 15, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Altérable (fragile, cassable, câble de faible structure, à nu, gainage disproportionné …)", 16, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Unique", 16, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Modifiable (remplaçable…)", 17, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Attractif (valeur marchande des câbles…)", 18, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Transportable (léger, dissimulable…)", 18, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Peu visible (oubliable, insignifiant, peu remarquable…)", 18, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Connaissance de l'existence et de la localisation du canal informatique ou de téléphonie", 18, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Accès physique ou logique au canal informatique ou de téléphonie (intégration légitime ou non d'un élément sur le canal)", 18, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Sujet à la dissipation (distraction, difficulté à cadrer ses activités…)", 19, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Peu discret (loquace, sans réserve…)", 20, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Routinier (habitudes facilitant l'espionnage récurrent)", 20, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Ressources (capacités de travail et disponibilités) insuffisantes pour les tâches assignées", 21, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Capacités physiques inappropriées aux conditions de travail (travail en pleine chaleur, avec une lumière insuffisante, dépassement de la capacité de locaux pour l'activité du personnel, utilisation de locaux à d'autres fins que celles prévues, inadéquation de locaux pour l'usage réel, contamination par des fumées d’incendie ou des produits nocifs ou désagréables…)", 21, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Capacités psychologiques inappropriées aux conditions de travail (faible résistance au stress ou à la pression permanente liée à l'activité, sujet à l'influence de la démotivation ambiante…)", 21, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Compétences inappropriées aux conditions d'exercice de ses fonctions (compétences insuffisantes ou mal employées, méthode de travail inadaptée, changement de la langue de travail…)", 21, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Incapacité à s'adapter au changement (nouveaux outils, nouvelles méthodes de travail…)", 21, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Limites physiques, psychologiques ou mentales", 22, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Influençable (naïf, crédule, obtus, faible estime de soi, faible loyauté…)", 23, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Manipulable (vulnérable à une pression sur elle-même ou son entourage)", 23, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Faible loyauté vis-à-vis de l'organisme", 24, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Faible satisfaction des besoins personnels (reconnaissance, salaire, motivation, ambiance, pérennité de l'emploi, incompatibilités déontologiques, déception professionnelle…)", 24, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Facilité de rupture du lien contractuel", 24, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Utilisable en dehors de l'usage prévu (exploitation nominale des biens essentiels)", 25, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Falsifiable (support papier au contenu modifiable ou effaçable)", 25, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'observer des données interprétables", 26, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Composants de mauvaise facture (fragile, facilement inflammable, sujet au vieillissement…)", 27, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("N'est pas approprié aux conditions d'utilisation (sensible à l'humidité…)", 27, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Portable", 28, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet d'altérer les flux communiqués (interception puis réémission, éventuellement après altération…)", 29, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Seule ressource de transmission pour le flux", 29, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Permet la modification du circuit organisationnel", 29, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Unique", 30, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Observable", 30, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Existence de limites quantitatives ou qualitatives", 31, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Instable", 32, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Unique", 32, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Modifiable (remplaçable…)", 33, DATE('now'), DATE('now'));
INSERT INTO VULN (libelle, idTVULN, dateCreation , dateModification) VALUES ("Utilité non reconnue", 34, DATE('now'), DATE('now'));

INSERT INTO BS_POSITIONS (xml, dateCreation , dateModification) VALUES("<root><entities/><links/><groups/></root>", DATE('now'), DATE('now'));
INSERT INTO BE_POSITIONS (xml, dateCreation , dateModification) VALUES("<root><entities/><links/><groups/></root>", DATE('now'), DATE('now'));